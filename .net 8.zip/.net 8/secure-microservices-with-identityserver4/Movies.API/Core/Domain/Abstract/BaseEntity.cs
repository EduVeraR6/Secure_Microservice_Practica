﻿namespace Movies.API.Core.Domain.Abstract
{
    public abstract class BaseEntity
    {
        public Guid ID { get; set; }
    }
}
    