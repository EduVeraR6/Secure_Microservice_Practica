﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Tareas.API.Models;

namespace Tareas.API.Data
{
    public class TareasAPIContext : DbContext
    {
        public TareasAPIContext (DbContextOptions<TareasAPIContext> options)
            : base(options)
        {
        }

        public DbSet<Tareas.API.Models.Tarea> Tarea { get; set; } = default!;
    }
}
