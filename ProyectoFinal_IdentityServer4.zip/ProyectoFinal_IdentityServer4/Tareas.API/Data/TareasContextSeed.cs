﻿using Tareas.API.Models;

namespace Tareas.API.Data
{
    public class TareasContextSeed
    {
        public static void SeedAsync(TareasAPIContext tareasContext)
        {
            if (!tareasContext.Tarea.Any())
            {
                List<Tarea> tareas = new List<Tarea>
{
                new Tarea
                {
                    Id = 1,
                    Title = "Comprar comestibles",
                    Description = "Comprar leche, huevos, y pan en el supermercado.",
                    IsCompleted = false,
                    Owner = "eduardo" 
                },
                new Tarea
                {
                    Id = 2,
                    Title = "Revisar correos electrónicos",
                    Description = "Revisar y responder los correos electrónicos pendientes del trabajo.",
                    IsCompleted = true,
                    Owner = "alice"
                },
                new Tarea
                {
                    Id = 3,
                    Title = "Hacer ejercicio",
                    Description = "Realizar una rutina de ejercicio de 30 minutos en casa.",
                    IsCompleted = false,
                    Owner = "bob"
                },
                new Tarea
                {
                    Id = 4,
                    Title = "Leer un libro",
                    Description = "Leer al menos un capítulo del libro 'Cien años de soledad'.",
                    IsCompleted = false,
                    Owner = "alice"
                },
                new Tarea
                {
                    Id = 5,
                    Title = "Preparar la cena",
                    Description = "Cocinar una cena saludable utilizando ingredientes frescos.",
                    IsCompleted = true,
                    Owner = "alice" 
                },
                new Tarea
                {
                    Id = 6,
                    Title = "Planificar vacaciones",
                    Description = "Investigar y planificar las próximas vacaciones de verano.",
                    IsCompleted = false,
                    Owner = "bob"
                }
            };

                tareasContext.Tarea.AddRange(tareas);
                tareasContext.SaveChanges();
            }
        }

    }
}
