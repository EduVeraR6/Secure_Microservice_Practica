﻿using IdentityModel;
using IdentityServer4.Models;
using IdentityServer4.Test;
using System.Security.Claims;

namespace IdentityServer
{
    public class Config
    {

        //clientes
        public static IEnumerable<Client> Clients =>
            new Client[]
            {
                new Client
                {
                    ClientId = "tareaClient",
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    ClientSecrets =
                    {
                        new Secret ("secret".Sha256())  
                    },
                    AllowedScopes = {"tareaAPI"}
                }

            };


        //Alcance

        public static IEnumerable<ApiScope> ApiScopes =>
            new ApiScope[] { 
                new ApiScope("tareaAPI" , "Tareas API")
            };


        //Recursos 

        public static IEnumerable<ApiResource> ApiResources => new ApiResource[] { };


        public static IEnumerable<IdentityResource> IdentityResources => new IdentityResource[] { };


        //Usuarios de prueba
        public static List<TestUser> TestUsers =>
              new List<TestUser> {
                new TestUser
                {
                   SubjectId = Guid.NewGuid().ToString(),
                   Username = "eduardo",
                   Password = "eduardo",
                   Claims = new List<Claim>
                   {
                      new Claim(JwtClaimTypes.GivenName, "eduardo"),
                      new Claim(JwtClaimTypes.FamilyName, "eduardo")
                   }
                }
            };

    }
}
